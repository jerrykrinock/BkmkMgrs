This data illustrates how, if a Safari Bookmarks.plist file is screwed up, in particular if it has multiple folders with title BookmarksBar and BookmarksMenu, although Safari's Edit Bookmarks somehow gets the correct data, the bookmarks data given to Pajara is incorrect.

## Contents of this folder

* Bookmarks.plist is the file in ~/Library/Safari.
* Tree.plist is the result of switching in "#warning Writing Pajara Tree Read back out to file" in ExtoreSafari.m.  It writes out the tree immediately after being received from Pajara.
* Import from Safari.bmco is what gets imported into a empty .bmco document which has Structure for Safari.
* Safari-Screenshot.png is a screenshot of Safari's Edit Bookmarks.

## Expected Result

Content of Safari.bmco should look like Safari's Edit Bookmarks

## Actual Result

In Safari.bmco, but not in Safari-Screenshot.png, the items in the soft BookmarksBar appear instead in hard Favorites.

## Analysis

Bookmarks.plist has *two* folders named "BookmarksBar", the real BookmarksBar, and a soft folder at root named "BookmarksBar"; and two folders named "BookmarksMenu", the real BookmarksMenu, and the Root is named "BookmarksMenu".

The incorrect data in Tree.plist is from the SafariPrivateFramework.  Here is the relevant line from Pajara logs:

2018-05-23-104353: Got root name=BookmarksMenu AE659C6C-C22D-490D-930D-94354820CF8F, 3 children

You see the root has the three children seen in Tree.plist, not the 5 children seen in Bookmarks.plist.

## Variation

This is somehow related to loading!  This test case contains 11 folders and 92 bookmarks.  But if you, for example, thin out some of the subfolders in TOP Reseach > TBC, so that there are only 50 bookmarks instead of 92, Delete All Content in Safari.bmco, then repeat the experiment – Import from all > Safari, the new Tree.plist apparently matches Bookmarks.plist, because the resulting Content in Safari.bmco matches the bookmarks in Safari's Edit Bookmarks, as it always should.