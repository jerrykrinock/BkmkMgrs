/*** MIGRATION POLICY EXAMPLES ***/

/* THIS FILE CONTAINS EXAMPLES OF STUFF YOU CAN DO IN A SUBCLASS OF NSMIGRATIONPOLICY */


#import "Bkmx0mm_0nnMigrationPolicy.h"

/*!
 @brief    The set of starkids whose -isExpanded attribute was YES in the
 document's store, before this migration

 @details   Since this migration involves moving the -isExpanded data values from the
 document's store to the (Local) Settings store, we need a way to remember it for a
 few seconds.  An instance variable won't work because a separate instance of this class
 is created and destroyed for migration of each store.  Hence this static variable.
 
 Both of these stores get migrated occur during -[BkmxDoc readFromURL:ofType:error:].
 Fortunately, the document's store (where the needed data comes from) gets migrated first,
 probably when super -readFromURL:ofType:error: is invoked.  The Settings store (where the
 data needs to go to) gets migrated a little later, when -[BkmxDoc linkToMacster] is invoked.
*/
static NSMutableSet* static_expandedStarkids = nil ;


@implementation Bkmx013_014MigrationPolicy

#define SETTINGS_PREFIX_LENGTH 9  // = length of "Settings-"
#define UUID_LENGTH 36

- (BOOL)beginEntityMapping:(NSEntityMapping*)mapping
				   manager:(NSMigrationManager*)manager
					 error:(NSError**)error_p {
	if (!static_expandedStarkids) {
		static_expandedStarkids = [[NSMutableSet alloc] init] ;
	}

	return YES ;
}

/*!
 @brief    Override for a method which creates new instances
 and migrates attributes, during migrations from version
 013 to 014, supporting the more complex entity mappings which
 could not be expressed in the .xcmappingmodel file.
 
 @details  This example invokes super
 
 Note that the plural "DestinationInstances" in this method's
 name does not imply that we're necessarily one to many.
 In fact this method is also used for simple attributes.
 They mean "DestinationInstance(s)".
*/
- (BOOL)createDestinationInstancesForSourceInstance:(NSManagedObject*)oldInstance
									  entityMapping:(NSEntityMapping*)inMapping
											manager:(NSMigrationManager*)inManager
											  error:(NSError**)error_p {
	BOOL ok = YES ;
	NSError* error = nil ;
	NSEntityDescription *sourceInstanceEntity = [oldInstance entity] ;	
	NSString* sourceInstanceEntityName = [sourceInstanceEntity name] ;
	if ([sourceInstanceEntityName isEqualToString:constEntityNameStark]) {
		ok = [super createDestinationInstancesForSourceInstance:oldInstance
												  entityMapping:inMapping
														manager:inManager
														  error:&error] ;
		if (ok) {
			if ([[oldInstance valueForKey:@"isExpanded"] boolValue] == YES) {
				NSString* starkid = [oldInstance valueForKey:@"starkid"] ;
				[static_expandedStarkids addObject:starkid] ;
			}
		}
		else {
			ok = NO ;
			NSString* msg = [NSString stringWithFormat:
							 @"Problem migrating %@",
							 oldInstance] ;
			error = [SSYMakeError(148469, msg) errorByAddingUnderlyingError:error] ;
		}
	}
	else {
		NSString* msg = [NSString stringWithFormat:
						 @"Error migrating database to new app version.  "
						 @"%s does not support source instance entity %@.",
						 __PRETTY_FUNCTION__,
						 sourceInstanceEntityName] ;
		ok = NO ;
		error = SSYMakeError(133678, msg) ;
		goto end ;
	}	 
	
end:
	if (error && error_p) {
		*error_p = error ;
	}
	
	return ok ;
}


/*!
 @brief    Override for custom migrations from version 5 to 6
 two support changes which could not be represented in the
 .xcmappingmodel file.
 
 @details  This example does not invoke super.
*/
- (BOOL)createDestinationInstancesForSourceInstance:(NSManagedObject*)inSourceInstance
									  entityMapping:(NSEntityMapping*)inMapping
											manager:(NSMigrationManager*)inManager
											  error:(NSError**)outError {
	NSManagedObject *newObject = nil ;
	NSEntityDescription *sourceInstanceEntity = [inSourceInstance entity] ;
	
	NSString* sourceInstanceEntityName = [sourceInstanceEntity name] ;
	
	// Change 1.  Map attribute constKeyRootSortable of entity constEntityNameBookshig
	// from being of type Integer16 to type Boolean.
	if ([sourceInstanceEntityName isEqualToString:constEntityNameBookshig] ) {
		newObject = [NSEntityDescription insertNewObjectForEntityForName:constEntityNameBookshig
												  inManagedObjectContext:[inManager destinationContext]] ;
		
		for (NSString* key in [[[inSourceInstance entity] attributesByName] allKeys]) {
			id oldValue = [inSourceInstance valueForKey:key] ;
			id newValue ;
			if ([key isEqualToString:constKeyRootSortable]) {
				// Old value was an NSNumber with Integer16 value.
				newValue = [NSNumber numberWithBool:([oldValue integerValue] == !0)] ;
			}
			else {
				newValue = oldValue ;
			}

			[newObject setValue:newValue
						 forKey:key] ;
		}
		
	}

	// Change 2.  In any instance of entity constEntityNameClient, if attribute
	// constKeyExformat is "Delicious", change it to constExformatDelicious1.
	else if ([sourceInstanceEntityName isEqualToString:constEntityNameClient] ) {
		newObject = [NSEntityDescription insertNewObjectForEntityForName:constEntityNameClient
												  inManagedObjectContext:[inManager destinationContext]] ;
		
		for (NSString* key in [[[inSourceInstance entity] attributesByName] allKeys]) {
			id oldValue = [inSourceInstance valueForKey:key] ;
			id newValue = oldValue ;
			if ([key isEqualToString:constKeyExformat]) {
				if ([oldValue isEqualToString:@"Delicious"]) {
					newValue = constExformatDelicious1 ;
				}
			}

			[newObject setValue:newValue
						 forKey:key] ;
		}
		
	}
	
	/* I think ww need this since we are not invoking super */
	[inManager associateSourceInstance:inSourceInstance
			   withDestinationInstance:newObject
					  forEntityMapping:inMapping] ;
	
	return YES ;
}


/*!
 @details  This method creates Starlobute instances from static_expandedStarkids,
 at the end of the Settings store migration, and then clears out static_expandedStarkids
 since it is no longer needed after this point, and in case another document is
 migrated during the current application run – we don't want to add starlobutes
 from the current document to any subsequently-migrated document.
 
 This method is essentially a no-op for all other store (document, Exids, Logs, Diaries)
 migrations.
*/
- (BOOL)endEntityMapping:(NSEntityMapping*)mapping
				 manager:(NSMigrationManager*)manager
				   error:(NSError**)error_p {
	NSError* error = nil ;
	BOOL ok = YES ;
	
	// Figure out the store's filename, so we'll know if we're migrating
	// the Settings store or not.
	NSManagedObjectContext* destinContext = [manager destinationContext] ;
	NSPersistentStore* destinStore = [destinContext store1] ;
	NSURL* url = [destinStore URL] ;
	NSString* storePath = [url path] ;
	NSString* filename = [[storePath lastPathComponent] stringByDeletingPathExtension] ;
	if ([filename hasPrefix:constBaseNameSettings]) {
		for (NSString* starkid in static_expandedStarkids) {
			NSManagedObject* starlobute = [NSEntityDescription insertNewObjectForEntityForName:constEntityNameStarlobute
																		inManagedObjectContext:destinContext] ;
			[starlobute setValue:starkid
						  forKey:constKeyStarkid] ;
			[starlobute setValue:[NSNumber numberWithBool:YES]
						  forKey:constKeyIsExpanded] ;
		}			
		
		ok = [destinContext save:&error] ;
		if (!ok) {
			NSLog(@"Internal Error 165817 %@", error) ;
		}
		
		[static_expandedStarkids release] ;
		static_expandedStarkids = nil ;
	}		
	
	return YES ;
}

/*!
 @brief   Sets a reliationship from a migrated TalderMap (TagMap or FolderMap)
 to one of the newly-created Tag objects
 
 @details Note that after writing ane testing this method, I realized that it could
 not be used because it creates a cross-store relationship.  (Tags and TalderMaps are
 actually in the document and settings stores, respectively.  So, before studying this
 code, confirm that you are not creating a cross-store relationship!!
 
 In the prior verison, `tag` was an string attribute of TalderMap and
 also a string attribute of Stark.  In Stage 1 of Core Data's Three-Stage
 Migration, new Tag objects should have been created, replacing the Tag
 strings.  We are now in Stage 2, which connects relationships.  When this
 method is passed in a TagMap or FolderMap destination instance, it gets
 the tag string from the associated source instance, then fetches the
 corresponding new Tag from the destination context.  It will be pretty neat
 if it works :)
 */
- (BOOL)createRelationshipsForDestinationInstance:(NSManagedObject *)destinInstance
                                    entityMapping:(NSEntityMapping *)mapping
                                          manager:(NSMigrationManager *)manager
                                            error:(NSError * _Nullable *)error_p {
    BOOL ok = [super createRelationshipsForDestinationInstance:destinInstance
                                                 entityMapping:mapping
                                                       manager:manager
                                                         error:error_p];

    NSError* error = nil;
    NSEntityDescription* entityDescription = [destinInstance entity];
    NSString* entityName = [entityDescription name];
    /* The 'tag` relationship which we need to connect is in TalderMap-entity,
     which is the super-entity of TagMap_entity and FolderMap_entity. */
    if (
        [entityName isEqualToString:constEntityNameFolderMap]
        ||
        [entityName isEqualToString:constEntityNameTagMap]
        )
    {
        if (ok) {
            NSString* mappingName = [self mappingNameForEntityName:entityName];
            NSManagedObject* sourceInstance = [[manager sourceInstancesForEntityMappingNamed:mappingName
                                                                        destinationInstances:@[destinInstance]] firstObject];
            NSString* tagString = [sourceInstance valueForKey:constKeyTag];
            if (tagString) {
                NSFetchRequest* fetchRequest = [NSFetchRequest fetchRequestWithEntityName:entityName];
                fetchRequest.predicate =[NSPredicate predicateWithFormat:@"tag like[cd] %@", tagString];
                NSArray* allObjects = [manager.sourceContext executeFetchRequest:[NSFetchRequest fetchRequestWithEntityName:entityName]
                                                                                error:&error];
                Tag* tag = [[manager.sourceContext executeFetchRequest:fetchRequest
                                                                      error:&error] firstObject];
                /*SSYDBL*/ NSLog(@"BONEHEAD Found %@", tag);
                if (error != nil) {
                    error = [error errorByAddingUserInfoObject:tagString
                                                        forKey:@"Attempted tag string"];
                    ok = NO;
                }
                
                if (tag == nil) {
                    NSDictionary* userInfo = @{
                        NSLocalizedDescriptionKey: [NSString stringWithFormat:@"Fetch found nil for any source %@ with tag %@",
                                                    entityName,
                                                    tagString]
                    };
                    error = [NSError errorWithDomain:[[NSString alloc] initWithFormat:@"%@ErrorDomain", [self className]]
                                                code:383721
                                            userInfo:userInfo];
                } else {
                    NSManagedObjectContext* destinationContext = manager.destinationContext;
                    tag = [NSEntityDescription insertNewObjectForEntityForName:constEntityNameTag
                                                        inManagedObjectContext:destinationContext];
                    [tag setValue:tagString
                           forKey:constKeyString];
                }
                
                [destinInstance setValue:tag
                                  forKey:constKeyTag];
            }
        }
    }
    
    if (error && error_p) {
        *error_p = error;
    }
    
    return ok;
}




@end