#import <Cocoa/Cocoa.h>


@interface Bkmx0mm_0nnMigrationPolicy : NSEntityMigrationPolicy {
}

@end
